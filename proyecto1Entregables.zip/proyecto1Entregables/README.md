

# Proyecto 1: Streams y Lambdas

## Paula Campaña Donoso
## Juan Francisco Cisneros

### Como ejecutar el programa :
-  Abrir una terminal en la carpeta proyecto1Entregables
-  cd proyecto1Entregables
-  javac Cliente.java
-  java Cliente